
import java.util.ArrayList;
import java.util.Random;


public class PatientTestQ12 {
    

    public static void main(String[] args) throws Exception {
      
        ArrayList<Patient> list = new ArrayList<>(){{
      
   add(new Patient(2, "p2", false));
    add(new Patient(4, "p4", false));
    add(new Patient(1, "p1", false));
    add(new Patient(3, "p3", true));
    add(new Patient(5, "p5", true));
    

  
         
}};

    

        // before sorting
        System.out.printf("%-15s%25s\n", "Before sorting", list); // should be [p1, p2, p3, p4, p5]

        // try bubble sort methods for Q1
        // Sorter.bubbleSort(list);
        // Sorter.bubbleSort(list, new PatientComparator());

        // other sort methods for Q2
        // Sorter.selectionSort(list);
         Sorter.insertionSort(list);

        // after sorting
        System.out.printf("%-15s%25s\n", "After sorting", list); // should be [p3, p5, p1, p2, p4]

        // return;
        

        System.out.printf("%20s\t%20s\t%20s\t%20s%n", "N", "Bubble", "Selection", "Insertion");

        for (int limit = 5000; limit <= 50000; limit += 5000) {
            ArrayList<Patient> b1 = LoopPatient(limit);
            ArrayList<Patient> b2 = (ArrayList<Patient>) b1.clone();
            ArrayList<Patient> b3 = (ArrayList<Patient>) b1.clone();

           // System.out.printf("Generated Test Set for N = %d%n", limit);

            long start = System.currentTimeMillis();
            Sorter.bubbleSort(b1);
            long end = System.currentTimeMillis();
            long bubble = end - start;

            long start1 = System.currentTimeMillis();
            Sorter.selectionSort(b2);
            long end1 = System.currentTimeMillis();
            long selection = end1 - start1;

            long start2 = System.currentTimeMillis();
            Sorter.insertionSort(b3);
            long end2 = System.currentTimeMillis();
            long insertion = end2 - start2;
       

           

            System.out.printf("%20s\t%20.3f\t%20.3f\t%20.3f%n", limit, bubble / 1000f, selection / 1000f,
                    insertion / 1000f);
        }
        
    }

    public static ArrayList<Patient> LoopPatient(int limit) {
        ArrayList<Patient> patience = new ArrayList<>();

        for (int c = 0; c <= limit; c++) {
            int booleanSolve = (int)(Math.random() * 2);
            int order = (int)(Math.random() * limit);

            patience.add(new Patient(order, "anonymous", booleanSolve == 1));
        }

        return patience;
    }

    // public static void Bubbling(){ //previous versions.
    // int t = 0;
    // ArrayList<Patient> a = new ArrayList<>();
    // ArrayList<ArrayList<Patient>> b = new ArrayList<>();
    // for (int s = 0; s < 5000 + t; s++) {

    // a.add(counterOfPatients, TimeAnaysis.TableofComparison().get(s));
    // counterOfPatients++;

    // if (s == 5000) {
    // t += 5000;
    // b.add(a);
    // b = new ArrayList<>();
    // }

    // }

    // System.out.println("done inputing");

    // for (int n = 0; n < b.size(); n++) {
    // for (int j = 0; j < b.get(n).size(); j++) {
    // Sorter.bubbleSort(b.get(n));
    // }
    // }
    // System.out.println("done sorting");

    // }

    // public static void Selecting(){
    // int t = 0;
    // int i = 0;
    // ArrayList<Patient> a = new ArrayList<>();
    // ArrayList<ArrayList<Patient>> b = new ArrayList<>();
    // for (int s = 0; s < 5000 + t; s++) {

    // a.add(counterOfPatients, TimeAnaysis.TableofComparison().get(s));
    // counterOfPatients++;

    // if (s == 5000) {
    // t += 5000;
    // b.add(a);
    // b = new ArrayList<>();
    // }
    // }

    // System.out.println("done inputing");

    // for (int n = 0; n < b.size(); n++) {
    // for (int j = 0; j < b.get(n).size(); j++) {
    // Sorter.selectionSort(b.get(n));
    // }
    // }
    // System.out.println("done sorting");
    // }

    // public static void Inserting(){
    // int t = 0;
    // int i = 0;
    // ArrayList<Patient> a = new ArrayList<>();
    // ArrayList<ArrayList<Patient>> b = new ArrayList<>();
    // for (int s = 0; s < 5000 + t; s++) {

    // a.add(counterOfPatients, TimeAnaysis.TableofComparison().get(s));
    // counterOfPatients++;

    // if (s == 5000) {
    // t += 5000;
    // b.add(a);
    // b = new ArrayList<>();
    // }
    // }

    // System.out.println("done inputing");

    // for (int n = 0; n < b.size(); n++) {
    // for (int j = 0; j < b.get(n).size(); j++) {
    // Sorter.insertionSort(b.get(n));
    // }
    // }
    // System.out.println("done sorting");
    // }

    // // public static ArrayList<ArrayList<Patient>>
    // TechnicalClone(ArrayList<ArrayList<Patient>> e){
    // // for (int n = 0; n < e.size(); n++) {
    // // for (int j = 0; j < e.get(n).size(); j++) {
    // // Sorter.bubbleSort(b.get(n));
    // // }
    // // }
    // // }

}
