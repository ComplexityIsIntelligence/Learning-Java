import java.util.ArrayList;
import java.util.Comparator;

public class Sorter {

    public static void bubbleSort(ArrayList<Patient> list) {

        for (int n = 0; n < list.size(); n++) {

            for (int i = 0; i < list.size() - n - 1; i++) {

                if (list.get(i).compareTo(list.get(i + 1)) > 0) {
                    Patient temp = list.get(i);

                    list.set(i, list.get(i + 1));
                    list.set(i + 1, temp);
                }

            }

        }
    }

    public static void bubbleSort(ArrayList<Patient> list, Comparator<Patient> comparator) {

        for (int n = 0; n < list.size(); n++) {

            for (int i = 0; i < list.size() - n - 1; i++) {

                if (comparator.compare(list.get(i), list.get(i + 1)) > 0) {
                    Patient temp = list.get(i);
                    list.set(i, list.get(i + 1));
                    list.set(i + 1, temp);
                }

            }

        }

    }

    // public static void selectionSort(ArrayList<Patient> list) { this is the
    // method i tried before the correct one

    // for (int n = 0; n < list.size() - 1; n++) {
    // int min = n;
    // for (int i = n; i < list.size() - 1; i++)
    // if (list.get(i).compareTo(list.get(i + 1)) < 0) { // change min to i
    // min = i + 1;
    // } else {
    // min = i;
    // }

    // Patient temp = list.get(n);
    // list.set(n, list.get(min));
    // list.set(min, temp);

    // }
    // }

    public static void selectionSort(ArrayList<Patient> list) {
        for (int MinFind = 0; MinFind < list.size(); MinFind++) {
            int CurrentMin = MinFind;
            for (int instanceCorrection = CurrentMin; instanceCorrection < list.size(); instanceCorrection++)
                if (list.get(CurrentMin).compareTo(list.get(instanceCorrection)) > 0)
                    CurrentMin = instanceCorrection;

            Patient temp = list.get(CurrentMin);
            list.set(CurrentMin, list.get(MinFind));
            list.set(MinFind, temp);

        }

    }

    // public static void insertionSort(ArrayList<Patient> list) { this is the
    // method i tried before the correct one

    // for (int i = 1; i < list.size(); i++) {

    // Patient store = list.get(i);
    // int n;
    // for (n = i; n > 0 ; n--)
    // if (list.get(i).compareTo(list.get(n - 1)) > 0)
    // list.set(n, list.get(n - 1));
    // else
    // break;
    // list.set(n, store);
    // }
    // }

    public static void insertionSort(ArrayList<Patient> list) {

        for (int i = 1; i < list.size(); i++) {

            Patient store = list.get(i);
            int n;
            for (n = i; n > 0; n--)
                if (list.get(n - 1).compareTo(store) > 0)
                    list.set(n, list.get(n - 1));
                else
                    break;
            // list.set(n - 1, store);
            list.set(n, store);
        }
    }

}
