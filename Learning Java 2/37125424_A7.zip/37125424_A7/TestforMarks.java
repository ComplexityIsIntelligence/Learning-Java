public class TestforMarks {
    public static void main(String[] args) throws Exception {
        
            new PatientManagerMark4() {
                {
                    start();

                }
            };
        
    }
}
