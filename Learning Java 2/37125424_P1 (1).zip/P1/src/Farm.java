public class Farm {
    private double availableFood;
    Animal[] animals = new Animal[4]; // change here as well

    public void setAvaibleFood(double availableFood) {
        if (availableFood <= 1000 && availableFood > 0) {
            this.availableFood = availableFood;
        } else {
            System.out.println("invalid available food amount");
        }
    }

    public Farm() {
        setAvaibleFood(1000);
        animals[0] = new Chicken();
        animals[1] = new Cow();
        animals[2] = new Llama();
        animals[3] = new Llama();

    }

    public void makeNoise() {
        for (int i = 0; i < animals.length; i++) {
            animals[i].sound();
        }

    }

    public void feedAnimals() {
        for (int i = 0; i < animals.length; i++) {

            availableFood = availableFood - animals[i].eat();

            if (availableFood <= 0) {
                System.out.println("There is not enough food on the farm");

                break;
            }

        }

    }

    public Animal[] getAnimals() {
        return animals;
    }

    public double getAvailableFood() {
        return availableFood;
    }

    public void setAvailableFood(double availableFood) {
        this.availableFood = availableFood;
    }

}
