public class Cow extends Animal {  
    static private int cowcounter;

    public Cow() {
        cowcounter++;
        super.setMealAmount(20);
        super.setName("Cow" + cowcounter);
    }

    public void jump() {
        System.out.println("The Cow is getting milked.They can do this with their utters.");
    }

    @Override
    public void sound() {
        if (isAlive() == true) {
            System.out.println("Moo!");
        }
    }
}
