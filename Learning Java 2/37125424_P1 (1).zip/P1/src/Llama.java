public class Llama extends Animal {  //remmember to change animals
    static private int Llamacounter;

    public Llama() {
        Llamacounter++;
        super.setMealAmount(7);
        super.setName("Llama" + Llamacounter);
    }

    public void jump() {
        System.out.println("The Llama is jumping.They can do this with their long legs.");
    }

    @Override
    public void sound() {
        if (isAlive() == true) {
            System.out.println("Hmmm!");
        }
        
    }

}
