public class Chicken extends Animal { 
    static private int chickencounter;

    public Chicken() {
        chickencounter++;
        super.setMealAmount(5);
        super.setName("Chicken" + chickencounter);
    }

    public void swin() {
        System.out.println("The chicken is swimming.They can  can do this with the use of their legs and wings.");
    }

    @Override
    public void sound() {
        if (isAlive() == true) {
            System.out.println("Cluck!");
        }
    }
}
