public class Animal {

    private String name;
    private double energy;
    private boolean alive;
    private double mealAmount;
    private double x;
    private double y;
    private double speedX;
    private double speedY;

    public Animal() {
        setEnergy(100);
        setSpeedX(1);
        setSpeedY(1);

    }

    public double getEnergy() {
        return energy;
    }

    public double getSpeedX() {
        return speedX;
    }

    public double getSpeedY() {
        return speedY;
    }

    public String getName() {
        return name;
    }

    public double getMealAmount() {
        return mealAmount;
    }

    public void setEnergy(double energy) {
        if (energy > 100 || energy < 0) {
            System.out.println("invalid energy amount");
        } else {
            this.energy = energy;
        }
        if (energy <= 17) {
            System.out.println(name + "" + "is starving");
        } else if (17 < energy && energy <= 50) {
            System.out.println(name + "" + "is hungry");
        } else
            return;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public void setMealAmount(double mealAmount) {
        if (mealAmount > 100 || mealAmount < 0) {
            System.out.println("invalid meal amount");
        } else {
            this.mealAmount = mealAmount;
        }
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSpeedY(double speedY) {
        this.speedY = speedY;
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setSpeedX(double speedX) {
        this.speedX = speedX;
    }

    public void setY(double y) {
        this.y = y;
    }

    public boolean isAlive() {
        if (energy > 0) {
            return true;
        } else {
            return false;
        }
    }

    public String toString() {
        String s = " ";
        if (alive = true) {
            s = "alive";
        } else {
            s = "dead";
        }
        return name + ":" + s + "(" + x + "," + y + ")" + " Energy=" + energy;
    }

    public void move() {
        if (alive = true) {
            x += speedX;
            y += speedY;
            energy -= 0.1;
        } else {
            System.out.println(name + "can't move.It is dead!");
        }
    }

    public void speak(String msg) {
        if (alive == true) {
            System.out.println(name + " says: " + msg);
        }

    }

    public void sound() {
        if (alive == true) {
            System.out.println("Uknown sound");
        }
    }

    public double eat() {
        double amount = 0;

        if (energy == 100) {
            System.out.println(name + " is Full");
            return 0;
        }

        if (alive == false) {
            System.out.println(name + " is dead");
            return 0;
        }

        double placekeeper = energy + mealAmount;
        if (placekeeper > 100) {
            double amountexceeded = placekeeper - 100;
            amount = mealAmount - amountexceeded;
        } else {
            amount = mealAmount;
        }
        energy = energy + amount;

        energy = Math.min(100, energy); // this is in case energy exceeds 100
        if (energy == 100) {
            System.out.println(name + " has eaten " + amount + " units" + " and is Full");
        } else {
            System.out.println(name + " has eaten " + amount);
        }

        return amount;
    }

}
