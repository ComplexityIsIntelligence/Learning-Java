import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Question2 {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // Self Note-perphaps change to relative path
        viewHex("C:/data.dat"); // method to invoke viewHex with the data.dat file
    }

    private static void viewHex(String filename) throws FileNotFoundException, IOException {
        File in = new File(filename); // instantiates a File named in
        int count = 1; // starts a counter which will be used for formating purposes

        try (DataInputStream news2 = new DataInputStream(new FileInputStream(in));) { // Creates an input stream to get
                                                                                      // binary data from file named in
            int[] x = new int[news2.available()]; // instaitates array which will contain data from File named in
            int b = 0;
            int c = 0;

            while ((b = (int) news2.read()) != -1) { // this while loop is used to iterate over the bits in the
                                                     // aforementioned file
                b = news2.read(); // this puts the value of the current byte into variable b
                x[c] = b; // this inserts the value of b into an array of integers x
                c++; // increament c for next value
            }

            for (int n : x) {
                System.out.printf("%s ",
                        String.format("%1$2s", Integer.toHexString(n).toUpperCase()).replace(' ', '0')); // conversion
                                                                                                         // to hexstring
                                                                                                         // and to
                                                                                                         // remove
                                                                                                         // spaces with
                                                                                                         // a 0

                if (count == 8) { // after the 8th instance this will insert a |
                    System.out.printf("| ");
                    count++;
                } else if (count == 16) { // after the 16th instance it leaves and line and resets count to 1 to allow
                                          // for the new line to be checked
                    System.out.println();
                    count = 1;
                } else {
                    count++; // if it is not the 16th or 6th instance it will continue working as normal
                             // through instances
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("file hasnt been found");
        } catch (IOException ex) {
            System.out.println("file failed because of input output operations");
        } catch (Exception f) {
            System.out.println("error!");
        }
    }
}
