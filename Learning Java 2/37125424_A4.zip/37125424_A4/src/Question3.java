import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

//methods at question at the end (restore and backup) 
public class Question3 {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        int parts = backup("src/syllabus COSC 121 102 with course ID.pdf", 0.25); // invokes method with the pdf file
                                                                                  // sylabus into 0.25 GB files
        restore("fileall.dat", parts); // restores all the peices into one file (the file file.inall.pdf is the result
                                       // of this code running and being converted to a pdf)
    }

    public static int backup(String filename, double partSize) throws IOException, FileNotFoundException {// function to
                                                                                                          // transfer
                                                                                                          // data to
                                                                                                          // smaller
                                                                                                          // specific
                                                                                                          // size files
        int y = 0;
        int partSizeinbytes = 0; // instantiating variable which is to be used later to see the number of bytes
                                 // in a file

        partSizeinbytes = (int) (partSize * 1000000); // converts size to GB

        File nx = new File(filename);

        int d = 0;

        try (DataInputStream w = new DataInputStream(new FileInputStream(nx));) { // data input scream to input byte
                                                                                  // data from chosen file
            int[] mew = new int[w.available()];// a array with the number of bytes
            int partZ = 0; // just a holder for byte data for the purpose of the transfer of data

            while ((partZ = (int) w.read()) != -1) { // while loop to iterate over all bytes
                /*
                 * Note-to-self: you can do it because the assigment opeeratiion evaluates to a
                 * value
                 * anything expression that can be evaluation to a value can be used in this
                 * way.
                 */
                mew[d++] = partZ;// puting the values into the array to work with an array of all the bytes
            }

            for (int o = 0; o < mew.length;) { // this for loop puts byte data into files and it for the total amount of
                                               // bytes to process
                try (DataOutputStream ip = new DataOutputStream(new FileOutputStream(new File("file" + y++)));) {// a
                                                                                                                 // data
                                                                                                                 // output
                                                                                                                 // stream
                                                                                                                 // to
                                                                                                                 // send
                                                                                                                 // data
                                                                                                                 // and
                                                                                                                 // a y
                                                                                                                 // increment
                                                                                                                 // to
                                                                                                                 // create
                                                                                                                 // a
                                                                                                                 // relative
                                                                                                                 // path
                                                                                                                 // for
                                                                                                                 // every
                                                                                                                 // new/different
                                                                                                                 // file.
                    for (int a = 0; a < partSizeinbytes && o < mew.length; a++, o++) { // transfers data assuring it is
                                                                                       // less than partsize and mew to
                                                                                       // avoid errors
                        ip.writeByte(mew[o]); // writing to the output stream
                    }
                }
            }

            return y;
        } catch (FileNotFoundException e) {
            System.out.println("file not found");
            System.out.println(e.getMessage());
            return -1;

        } catch (IOException ex) {
            System.out.println("IO exception");
            System.out.println(ex.getMessage());
            return -1;
        } catch (Exception j) {
            System.out.println("IO exception");
            System.out.println(j.getMessage());
            return -1;
        }

    }

    public static int restore(String filename, double numofPieces) throws IOException, FileNotFoundException {// method
                                                                                                              // to
                                                                                                              // combine
                                                                                                              // all of
                                                                                                              // the
                                                                                                              // smaller
                                                                                                              // files
                                                                                                              // of
                                                                                                              // backup
        try (DataOutputStream wq = new DataOutputStream(new FileOutputStream("file inall"));) { // output stream to
                                                                                                // transfer byte data to
                                                                                                // the specified file in
                                                                                                // the code
            int count = 0;

            for (int x = 0; x < numofPieces; x++) { // iterates over the number of peices
                try (DataInputStream xw = new DataInputStream(new FileInputStream("file" + x));) {// a way to retreive
                                                                                                  // data from all files
                                                                                                  // using a stream that
                                                                                                  // uses x to specific
                                                                                                  // the file used to
                                                                                                  // get all the data
                                                                                                  // into a single array
                    int e = 0; // just the instantiation of a variable to hold data

                    while ((e = xw.read()) != -1) { // while loop to retrieve all the bytes from each file
                        wq.writeByte(e); // writes out the byte e to the file using the stream
                        count++; // this is an integer value of the number of bytes to indicate size
                    }
                }
            }

            return count; // returns to size of the file in integer format type
        } catch (FileNotFoundException e) {
            System.out.println("file not found");
            System.out.println(e.getMessage());
            return -1;
        } catch (IOException ex) {
            System.out.println("IO exception");
            System.out.println(ex.getMessage());
            return -1;
        } catch (Exception exg) {
            System.out.println("IO exception");
            System.out.println(exg.getMessage());
            return -1;
        }

    }
}
