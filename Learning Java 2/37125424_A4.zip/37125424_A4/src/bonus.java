import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

//methods of buffered restore and buffered back up are  at the end (restore and backup) 
public class bonus {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        long startbeforebuffer = System.currentTimeMillis();
        System.out.println("      Without buffer       ");
        System.out.println("backing up ...");
        int parts = backup("src/syllabus COSC 121 102 with course ID.pdf", 0.25);
        System.out.println("restoring...");
        restore("fileall.dat", parts);
        long endbeforebuffer = System.currentTimeMillis();
        System.out.println("Done in " + (endbeforebuffer - startbeforebuffer));
        System.out.println();

        System.out.println("      With buffer       ");

        long startafterbuffer = System.currentTimeMillis();
        System.out.println("backing up ...");
        int parts1 = Bufferedbackup("src/syllabus COSC 121 102 with course ID.pdf", 0.25);
        System.out.println("restoring...");
        Bufferedrestore("fileall.dat", parts1);

        long endafterbuffer = System.currentTimeMillis();
        System.out.println(" Done in " + (endafterbuffer - startafterbuffer));

        System.out.println();

    }

    public static int backup(String filename, double partSize) throws IOException, FileNotFoundException {
        int y = 0;
        int partSizeinbytes = 0;

        partSizeinbytes = (int) (partSize * 1000000);

        File nx = new File(filename);
        long count = nx.length();

        int d = 0;

        try (DataInputStream w = new DataInputStream(new FileInputStream(nx));) {

            int[] mew = new int[(int) count];
            int partZ = 0;

            while ((partZ = (int) w.read()) != -1) {

                mew[d++] = partZ;
            }

            for (int o = 0; o < mew.length;) {
                try (DataOutputStream ip = new DataOutputStream(new FileOutputStream(new File("file" + y++)));) {
                    for (int a = 0; a < partSizeinbytes && o < mew.length; a++, o++) {
                        ip.writeByte(mew[o]);
                    }
                }
            }

            return y;
        } catch (FileNotFoundException e) {
            System.out.println("file not found");
            System.out.println(e.getMessage());
            return -1;

        } catch (IOException ex) {
            System.out.println("IO exception");
            System.out.println(ex.getMessage());
            return -1;
        } catch (Exception j) {
            System.out.println("IO exception");
            System.out.println(j.getMessage());
            return -1;
        }

    }

    public static int restore(String filename, double numofPieces) throws IOException, FileNotFoundException {
        try (DataOutputStream wq = new DataOutputStream(new FileOutputStream("file inall"));) {
            int count = 0;

            for (int x = 0; x < numofPieces; x++) {
                try (DataInputStream xw = new DataInputStream(new FileInputStream("file" + x));) {
                    int e = 0;

                    while ((e = xw.read()) != -1) {
                        wq.writeByte(e);
                        count++;
                    }
                }
            }

            return count;
        } catch (FileNotFoundException e) {
            System.out.println("file not found");
            System.out.println(e.getMessage());
            return -1;
        } catch (IOException ex) {
            System.out.println("IO exception");
            System.out.println(ex.getMessage());
            return -1;
        } catch (Exception exg) {
            System.out.println("IO exception");
            System.out.println(exg.getMessage());
            return -1;
        }

    }

    public static int Bufferedbackup(String filename, double partSize) throws IOException, FileNotFoundException {

        int y = 0;
        int partSizeinbytes = 0;

        partSizeinbytes = (int) (partSize * 1000000);

        File nx = new File(filename);
        long count = nx.length();
        int d = 0;

        try (BufferedInputStream w = new BufferedInputStream(new FileInputStream(nx));) {

            int[] mew = new int[(int) count];
            int partZ = 0;

            while ((partZ = (int) w.read()) != -1) {
                /*
                 * Note-to-self: you can do it because the assigment opeeratiion evaluates to a
                 * value
                 * anything expression that can be evaluation to a value can be used in this
                 * way.
                 */
                mew[d++] = partZ;
            }

            for (int o = 0; o < mew.length;) {
                try (BufferedOutputStream ip = new BufferedOutputStream(
                        new FileOutputStream(new File("file" + y++)));) {
                    for (int a = 0; a < partSizeinbytes && o < mew.length; a++, o++) {
                        ip.write(mew[o]);
                    }
                }
            }

            return y;
        } catch (FileNotFoundException e) {
            System.out.println("file not found");
            System.out.println(e.getMessage());
            return -1;

        } catch (IOException ex) {
            System.out.println("IO exception");
            System.out.println(ex.getMessage());
            return -1;
        } catch (Exception j) {
            System.out.println("IO exception");
            System.out.println(j.getMessage());
            return -1;
        }

    }

    public static int Bufferedrestore(String filename, double numofPieces) throws IOException, FileNotFoundException {
        try (BufferedOutputStream wp = new BufferedOutputStream(new FileOutputStream("file inall"));) {

            int count = 0;

            for (int x = 0; x < numofPieces; x++) {
                try (BufferedInputStream xw = new BufferedInputStream(new FileInputStream("file" + x));) {

                    int e = 0;

                    while ((e = xw.read()) != -1) {
                        wp.write(e);
                        count++;
                    }
                }
            }

            return count;
        } catch (FileNotFoundException e) {
            System.out.println("file not found");
            System.out.println(e.getMessage());
            return -1;
        } catch (IOException ex) {
            System.out.println("IO exception");
            System.out.println(ex.getMessage());
            return -1;
        } catch (Exception exg) {
            System.out.println("IO exception");
            System.out.println(exg.getMessage());
            return -1;
        }

    }
}
