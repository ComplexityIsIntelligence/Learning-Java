import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Question1 {
  public static void main(String[] args) throws FileNotFoundException, IOException { // thows exception specific to the
                                                                                     // code in case they come up
    int count = 0;
    File file = new File("count.dat"); // creates File named file
    if (file.exists()) {// checks if file exists
      DataOutputStream writer1 = new DataOutputStream(new FileOutputStream(file));// creates a stream that can output to
                                                                                  // file

      writer1.writeInt(count);// writes the intial value of count into file

      try (DataInputStream reader1 = new DataInputStream(new FileInputStream(file));) { // creates an input stream to
                                                                                        // write data into file that
                                                                                        // closes after the try has
                                                                                        // ended

        count = reader1.readInt(); // reads the integer in file

        for (int x = 0; x < 5; x++) { // general function that loops 5 times

          System.out.println("pizza");
          count++;
        }
        writer1.writeInt(count); // writes the current count after loop which will be 5
        System.out.println("The value of count after the loop function is launched is " + reader1.readInt());
      }
      writer1.close(); // closes output stream
    }
  }
}
