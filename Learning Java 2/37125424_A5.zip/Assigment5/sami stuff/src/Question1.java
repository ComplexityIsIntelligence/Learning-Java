public class Question1 {

    public static void main(String[] args) {
        String si = "sio";

        System.out.println(Reverseit(si, si.length() - 1));
    }

    public static String Reverseit(String s) {
        return (Reverseit(s, s.length() - 1));
    }

    public static String Reverseit(String s, int pointerofElements) {


        String StringtostoreReverse= "";

        if (pointerofElements <= 0) {
            StringtostoreReverse += s.charAt(pointerofElements);
        } else {
            StringtostoreReverse += s.charAt(pointerofElements) + Reverseit(s, pointerofElements--);
        }
        return StringtostoreReverse;
    }
}
