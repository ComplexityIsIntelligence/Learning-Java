
//the base case is if n reachs 0 which indicates the zeroth index of the String which in that case would just
//plainly concatenate the String and end the recursion because there will do no 
//recruvive call anymore which will end the if-else and recursion to return a String of the reverse of all letter.
//The recursive call is the reversalOfString(s.substring(0, n)) which when sees that n is not 0 and since it would 
//never skip over zero because of the properties of the functions
//in particular substring which excludes 1 in every String made when the new String with the last character removed is
//passed again recursively to store a String which would keep calling until
//it reached the last case and because the way in which the stack goes on a first in last out stituation in this instance
//it would print it backwards purely because of how it was executed.

public class Question2 {
    public static void main(String[] args) {
        System.out.println(reversalOfString("UBC-O"));

    }

    public static String reversalOfString(String s) {
        int n = s.length() - 1;
        String sreverse = "";
        if (n == 0) {
            sreverse += s.charAt(n);

        } else {

            sreverse += s.charAt(n) + reversalOfString(s.substring(0, n));

        }
        return sreverse;
    }
}
