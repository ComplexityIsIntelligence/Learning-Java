

 // The base case for this code is if n which is indicates in terms of an index
    // that the first value of the sequence is reached and it should return 0.5
    // which is the first value and
    // the stack will then recieve its last function in the stack and execute the
    // code before and due to this it will print a certain output.
    // The recurvive call is mentioned in line 21 which is patternprinter(n-1);
    // which goes to the previous value of n which indicates an index which will
    // decrease till 0 and when reached it will return 0 to the previous
    // recursive funtions and execute the code

public class Question1 {

    public static void main(String[] args) {
        for (int i = 1; i < 6; i++) {
            System.out.printf("i=%d   f(i)=%.2f", i, patternprinter(i));
            System.out.println();
        }

    }

    public static double patternprinter(double n) {
        double c = 0;
        if (n == 1) {
            return 0.5;
        } else {
            c = 1 / (2 * n);
            return c + patternprinter(n - 1);
        }
    }
}
