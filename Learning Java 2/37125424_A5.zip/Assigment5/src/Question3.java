
// The base case for the code is if end is less than zero the recursion ends
// because suppose we are at a value when end is equal to 2 then the code would
// do to the else check
// if it is equal to the the character it will increment our static variable
// count and then go and check if end is greater than 0 ;suppose we just finshed
// 1 and the method computers
// 0 as the end it would increment because start=end and in our if it increments
// counter then and now it will check if end is greater than zero which it is
// not so it is therefore the
// base case and the recursion would be LetterOccurranceChecker(x, c, start, end
// - 1) which is the helper method to public static int
// LetterOccurranceChecker(String x, char c)
// this will recurse pointing to different indexs of the String x
//Base case is the oppositon of in line 61 if the if-statement doesnt execute and recursion in line 62

import java.util.Scanner;

public class Question3 {
    private static int counter;

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        System.out.println("enter a string");
        String word = in.nextLine();
        System.out.println("enter a character");
        String letter = in.next();
        char letteratquestion = letter.charAt(0);
        int thecount = LetterOccurranceChecker(word, letteratquestion);
        char formater = '"';
        System.out.println(letteratquestion + " appears " + thecount + " time(s) in " + formater + word + formater);
        in.close();

    }

    public static int LetterOccurranceChecker(String x, char c) {

        return LetterOccurranceChecker(x, c, 0, x.length() - 1);

    }

    public static int getCounter() {
        return counter;
    }

    public static int LetterOccurranceChecker(String x, char c, int start, int end) {
        // to store counter a static variable independant of the method was made
        // another possible way would have been to pass it through the method parameters
        if (start == end) {
            if (x.charAt(start) == c) {
                counter++;
            }

        } else {
            if (x.charAt(end) == c) {
                counter++;
            }

        }
        if (end > 0) {
            LetterOccurranceChecker(x, c, start, end - 1);
        }

        return getCounter();

    }
}
