
// the base case is like in question 3 not expicit but it is the instance. It is statememt that if the in line 28 turns false then instead of recursing it will
//end the just state the name.
//If the file is a directory it will recurselistAllFiles(f, spaces1); and go into the method public static void listAllFiles(File dir, String spaces) which will again go over the files
//within this directory and then again check if there are files and if not it will print them ending the recursion
//This code works on the basis of an unknown amount of files and directories which check only the amount in the foreach loop to determine the number of files in the directory

import java.io.File;

public class Question4 {
    public static void main(String[] args) {
        File dir = new File("C:/Folder A");
        listAllFiles(dir);
    }

    public static void listAllFiles(File dir) {
        listAllFiles(dir, "");
    }

    public static void listAllFiles(File dir, String spaces) {

        if (dir.exists()) {
            if (dir.isDirectory()) {
                System.out.println(spaces + "[" + dir.getName() + "]");
                File[] filelisitng = dir.listFiles();

                for (File f : filelisitng) {

                    if (f.isDirectory()) {

                        String spaces1 = spaces + " ";
                        listAllFiles(f, spaces1);

                    } else {
                        System.out.println(" " + spaces + f.getName());
                    }

                }

            }

        }
    }
}
