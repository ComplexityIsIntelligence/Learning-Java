package Questions;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Question2 {
	public static void main(String[] args) throws Exception {

		printShuffled("C:\\Users\\ali12201.stu\\Downloads\\A6\\story.txt");
	}

	public static void printShuffled(String filename) throws Exception {

		File file = new File(filename);
		try (Scanner scanner = new Scanner(file)) {

			DataInputStream u = new DataInputStream(new FileInputStream(file));
			Path path = Paths.get(filename);
			byte[] numberofbytes = Files.readAllBytes(path);
			String stringofbytes = new String(numberofbytes);
			int lenghtofarraylist = stringofbytes.length();
			u.close();

			ArrayList<String> Sentences = new ArrayList<>(lenghtofarraylist / 50);

			scanner.useDelimiter(("[.:!?]"));

			while (scanner.hasNext()) {
				Sentences.add(scanner.next());

			}
			Sentences.trimToSize();
			Collections.shuffle(Sentences);

			for (int x = 0; x < Sentences.size(); x++) {
				System.out.println((Sentences.get(x)).trim() + ".");
			}
		}

	}
}