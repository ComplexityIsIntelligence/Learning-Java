package Questions;

import java.util.ArrayList;
import java.util.Scanner;

public class Question1 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		ArrayList<Integer> arraylist = new ArrayList<Integer>();
		System.out.println("Enter 5 integers");
		for (int x = 0; x < 5; x++) {
			int y = in.nextInt();
			arraylist.add(y);

		}
		ArrayList<Integer> arraylistWithNoDuplicates = noDuplicates(arraylist);
		System.out.println(arraylistWithNoDuplicates.toString());

	}

	public static ArrayList<Integer> noDuplicates(ArrayList<Integer> list) {
		ArrayList<Integer> ListWithNoDuplicates = new ArrayList<>();
		for (int n = 0; n < list.size(); n++) {
			if (!ListWithNoDuplicates.contains(list.get(n))) {
				ListWithNoDuplicates.add(list.get(n));

			}

		}
		return ListWithNoDuplicates;

	}
}
