import java.util.Arrays;

public class testingforQuestion4 {

    public static void main(String[] args) throws CloneNotSupportedException {
        Shape[] shapes1 = { new Rectangle(2, 3), new Rectangle(4, 5), new Rectangle(1, 1), new Hexagon(2),
                new Hexagon(6) };
        double totalArea = 0;

        for (int x = 0; x < shapes1.length; x++) {
            totalArea += (shapes1[x]).getArea();

        }
        System.out.println("total area of all shapes in shapes1 is" + totalArea);

        System.out.println();

        Shape[] shapes2 = (Shape[]) shapes1.clone();

        Arrays.sort(shapes2);
        System.out.println();
        System.out.println();
        System.out.println("shapes1 has been cloned to shapes2");
        System.out.println("shapes 2 has been reordered");
        System.out.printf(" %s %25s", "Areas of shape1", "Areas of shape2");
        System.out.println();
        for (int x = 0; x < shapes2.length; x++) {

            System.out.printf(" %.2f %25.2f", shapes1[x].getArea(), shapes2[x].getArea());
            System.out.println();

        }

    }
}
