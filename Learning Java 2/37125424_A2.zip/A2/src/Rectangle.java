public class Rectangle extends Shape {
    private int w;
    private int l;

    public Rectangle() {

    }

    public Rectangle(int w, int l) {
        setL(l);
        setW(w);

    }

    @Override
    public double getArea() {
        return l * w;
    }

    @Override
    public double getPerimeter() {
        return 2 * l + 2 * w;
    }

    @Override
    public int compareTo(Shape s) {
        if (this.getArea() == s.getArea()) {
            return 0;
        } else if (this.getArea() > s.getArea()) {
            return 1;

        } else {
            return -1;
        }

    }

    public int getL() {
        return l;
    }

    public int getW() {
        return w;
    }

    public void setW(int w) {
        this.w = w;
    }

    public void setL(int l) {
        this.l = l;
    }

    public String toString() {
        return "side width: " + getW() + " side length: " + getL() + " Area: " + getArea() + " Perimeter"
                + getPerimeter();
    }
}
