import java.util.Scanner;

public class HexagonTester {
    public static void main(String[] args) throws CloneNotSupportedException {
        boolean calim;
        String statement = " ";
        Scanner input = new Scanner(System.in);

        System.out.print("Color ");
        String x = input.nextLine();

        System.out.println();
        System.out.print("Filled Yes/No ");
        String y = input.nextLine();

        System.out.println();
        System.out.print("Side Lenght ");
        int z = input.nextInt();

        if (y.equalsIgnoreCase("Yes")) {
            calim = true;
            statement = "filled";
        } else {
            calim = false;
            statement = "not filled";
        }
        System.out.println("First Hexagon");
        Shape firstone = new Hexagon(z);
        firstone.setColor(x);
        firstone.setFilled(calim);
        System.out.println("color " + firstone.getColor() +"."+ statement+".");
        System.out.println(firstone.toString());

        System.out.println("Second Hexagon");
        Shape secondone = (Hexagon) firstone.clone();
        System.out.println("color " + secondone.getColor()  + statement);
        System.out.println(secondone.toString());

        if (firstone.compareTo(secondone) == 0) {
            System.out.println("Both hexagons are identitical.");
        } else {
            System.out.println("Both hexagons are not identical.");
        }
    }

}
