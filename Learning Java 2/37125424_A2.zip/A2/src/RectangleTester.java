import java.util.Scanner;
public class RectangleTester {
    public static void main(String[] args) throws CloneNotSupportedException {
        boolean calim;
        String statement = " ";
        Scanner input = new Scanner(System.in);

        System.out.print("Color ");
        String x = input.nextLine();


        System.out.print("Filled Yes/No ");
        String y = input.nextLine();

        System.out.print(" Width and Lenght ");
        int w = input.nextInt();
        int z = input.nextInt();

        if (y.equalsIgnoreCase("Yes")) {
            calim = true;
            statement = "filled";
        } else {
            calim = false;
            statement = "not filled";
        }
        System.out.println("First Rectangle");
        Shape firstone = new Rectangle(z,w);
        firstone.setColor(x);
        firstone.setFilled(calim);
        System.out.println("color " + firstone.getColor() +"."+ statement+".");
        System.out.println(firstone.toString());

        System.out.println("Second Rectangle");
        Shape secondone = (Rectangle) firstone.clone();
        System.out.println("color " + secondone.getColor()  + statement);
        System.out.println(secondone.toString());

        if (firstone.compareTo(secondone) == 0) {
            System.out.println("Both rectangles are identitical.");
        } else {
            System.out.println("Both rectangles are not identical.");
        }
    }
}
