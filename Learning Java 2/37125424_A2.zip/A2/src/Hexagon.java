public class Hexagon extends Shape {
    private double s;

    public Hexagon(){

    }
    public Hexagon(double s){
setS(s);
    }
    @Override
    public double getArea() {
        return (3 * Math.sqrt(3) * s*s) / 2;
    }

    @Override
    public double getPerimeter() {
        return 6 * s;
    }

    @Override
    public int compareTo(Shape s) {
        if (this.getArea() == s.getArea()) {
            return 0;
        } else if (this.getArea() > s.getArea()) {
            return 1;

        } else {
            return -1;
        }

    }

 

    public double getS() {
        return s;
    }

    public void setS(double s) {
        this.s = s;  
    }
    public String toString(){
        return "side length: "+getS()+" Area: "+getArea()+" Perimeter"+getPerimeter();
    } 
}
