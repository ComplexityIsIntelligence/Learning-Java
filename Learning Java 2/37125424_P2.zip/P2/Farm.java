


import java.util.Arrays;

public class Farm {
    private double availableFood;
    private static Animal[] animals = new Animal[100];
    private static Animal[] animalscopy;
    public static int arraycounterofanimals = 0;

    // a counter to help track which position of the array the object
    // should fill.
    // it increments everytime it is used to put something in the array
    public Farm() {
        setAvailableFood(1000);
        animals = new Animal[100];
        add(new Chicken()); // adding specified animals
        add(new Cow());
        add(new Llama());
        add(new Llama());

    }

    public boolean addClone(Animal anim) throws CloneNotSupportedException { // cloning animals
        if (arraycounterofanimals < 100) {
            if (anim instanceof Chicken) {
                animals[arraycounterofanimals] = (Chicken) (anim).clone();
            } else if (anim instanceof Cow) {
                animals[arraycounterofanimals] = (Cow) (anim).clone();
            } else {
                animals[arraycounterofanimals] = (Llama) (anim).clone();
            }
            arraycounterofanimals++;
            return true;
        } else
            System.out.println("no empty spots in animal array");
        return false;
    }

    public void animSort() { // sorting animals

        Arrays.sort(getAnimals());
        for (int x = 0; x < arraycounterofanimals; x++) {
            animals[x] = animalscopy[x];
        }
    }

    public static boolean add(Animal anim) { // adding animals
        if (arraycounterofanimals < 100) {
            if (anim instanceof Chicken) {
                animals[arraycounterofanimals] = (Chicken)anim;

                arraycounterofanimals++;
                return true;
            } else if (anim instanceof Cow) {
                animals[arraycounterofanimals] = (Cow)anim;

                arraycounterofanimals++;
                return true;
            } else {
                animals[arraycounterofanimals] = (Llama)anim;

                arraycounterofanimals++;
                return true;
            }
        } else {
            System.out.println("no empty spots in animal array");
            return false;
        }

    }

    public Animal[] getAnimals() {
        // making array that
        animalscopy = new Animal[arraycounterofanimals]; // that has no null values
        for (int x = 0; x < arraycounterofanimals; x++) {
            animalscopy[x] = animals[x];

        }
        return animalscopy;

    }

    public void printAnimals() {
        for (int y = 0; y < arraycounterofanimals; y++) { // printing animal array

            System.out.println(getAnimals()[y].toString());

        }
    }

    public int getNumChickens() { // method to get number of chickens
        int numberofchickens = 0;
        for (int y = 0; y < arraycounterofanimals; y++) {
            if (animals[y] instanceof Chicken) {
                numberofchickens++;
            }

        }
        return numberofchickens;

    }

    public int getNumCows() {
        int numberofcows = 0; // method to get number of cows
        for (int y = 0; y < arraycounterofanimals; y++) {
            if (animals[y] instanceof Cow) {
                numberofcows++;
            }

        }
        return numberofcows;

    }

    public int getNumLlamas() {
        int numberofLlamas = 0; // method to get number of Llamas
        for (int y = 0; y < arraycounterofanimals; y++) {
            if (animals[y] instanceof Cow) {
                numberofLlamas++;
            }

        }
        return numberofLlamas;

    }

    public void printSummary() { // prints Summary of farm details
        System.out.println(arraycounterofanimals + " Animals (" + getNumChickens() + " chickens, " + getNumCows()
                + " cows, " + getNumLlamas() + " Llamas)");
        System.out.println(availableFood + " units of available food");

    }

    public void makeNoise() { // all animals make their sound (Moo, Cluck, etc)
        for (Animal animal : animals)
            animal.sound();
    }

    public void feedAnimals() { // restore energy of all animals and deduct amount eaten from availableFood
        for (Animal animal : animals)
            if (availableFood >= Math.min(animal.getMealAmount(), (100 - animal.getEnergy())))
                // no penalty if student uses: if(availableFood >= animal.getMealAmount())
                availableFood -= animal.eat();
            else
                System.out.println("Not enough food for your animals! You need to collect more food items.");
    }

    public double getAvailableFood() {
        return availableFood;
    }

    public void setAvailableFood(double availableFood) {
        if (availableFood >= 0 && availableFood <= 1000)
            this.availableFood = availableFood;
    }

}
