import java.util.Scanner;

public class Question1Part1 {

    // This is question 1 with defensive programming

    public static void main(String[] args) {
        String s = "";
        int[] randomnumbersarray = new int[50];
        for (int x = 0; x < 50; x++) {
            randomnumbersarray[x] = (int) (Math.random() * 100);

        }

        Scanner input = new Scanner(System.in);

        System.out.println("Enter an index between 0 and 49");
        int choiceofindex = input.nextInt();

        do {
            if (choiceofindex < 50 && choiceofindex > -1) {
                int storage = randomnumbersarray[choiceofindex];
                System.out.println("The value at the index is " + storage);
                s = "valid";
            } else {
                s = "invalid";
                System.out.println("invalid");
                System.out.println("Out of bounds. Try again");
                choiceofindex = input.nextInt();

            }

        } while (s.equals("invalid"));
        input.close();
    }
}
