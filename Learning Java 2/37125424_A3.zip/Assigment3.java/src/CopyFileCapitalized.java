
import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

public class CopyFileCapitalized {
//This is the answer to Quesiton 4
    public static void main(String[] args) throws Exception {
        String censoredWords[] = { "ABC", "XYZ" };

        Scanner textFile = new Scanner(new File("source.txt"));

        String line = "";

        while (textFile.hasNextLine()) {
            line += textFile.nextLine() + "\r\n";
        }

        String solution = replaceCensoredWords(line, censoredWords);
  String solutionUppercase=solution.toUpperCase();
        PrintWriter op = new PrintWriter(new File("working code.txt"));
        op.print(solutionUppercase);
        op.close();

    }

    private static String replaceCensoredWords(String line, String[] censoredWords)throws Exception {
        String s = "";
        String arrayofStrings[] = line.split(" ");
        for (int x = 0; x < arrayofStrings.length; x++) {
            if (arrayofStrings[x].equalsIgnoreCase("ABC") || arrayofStrings[x].equalsIgnoreCase("XYZ")) {
                arrayofStrings[x] = "...";
            }
        }
        for (int c = 0; c < arrayofStrings.length; c++) {

            s += arrayofStrings[c] + " ";
        }

        return s.trim();
    }

}
