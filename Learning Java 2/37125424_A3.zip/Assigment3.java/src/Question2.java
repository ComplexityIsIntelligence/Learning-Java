import java.util.InputMismatchException;
import java.util.Scanner;

public class Question2 {
    public static void main(String[] args) {
        // note: the while got tedious so I used recursion
        Recurser();
    }

    public static void Recurser() {

        double formularesult1 = 0;
        double formularesult2 = 0;
        String operator = "";
        double result = 0;

        Scanner input = new Scanner(System.in);
        System.out.println("enter a  simple mathematical operation");

        try {

            formularesult1 = input.nextDouble();
            operator = input.next();
            formularesult2 = input.nextDouble();
            input.close();
            if (operator.equals("+")) {
                result = formularesult1 + formularesult2;
            } else if (operator.equals("-")) {
                result = formularesult1 - formularesult2;
            } else if (operator.equals("/")) {
                result = formularesult1 / formularesult2;
            } else if (operator.equals("*")) {
                result = formularesult1 * formularesult2;

            } else {
                throw new InputMismatchException("Try again");
            }

            System.out.println(result);

        } catch (InputMismatchException e) {
            System.out.println("invalid format try again");

            Recurser();

        }

    }

}
