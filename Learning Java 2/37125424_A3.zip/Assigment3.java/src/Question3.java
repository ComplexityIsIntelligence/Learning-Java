import java.util.InputMismatchException;
import java.util.Scanner;

public class Question3 {

    public static void main(String[] args) {
        /*
         ** The exception thrown was a NumberFormatException.
         ** This happens because Double.parseDouble() could not convert
         ** the case of 4.5a to a double but that is not possible because a is not a
         * double.
         ** so it has no appropriate numerical type so this will not run because java
         * couldn't convert it to a double.
         ** There were numerical operations of a character a which is invalid so
         ** The solution found was using a NumberFormartException in the catch and
         * preforming the same
         * list of operations as the other catch exception handlers which would begin
         * the recursion unitl
         * valid.
         */

        Recurser();
    }

    public static void Recurser() {
        String t1 = "";
        String t2 = "";
        double formularesult1 = 0;
        double formularesult2 = 0;
        String operator = "";
        double result = 0;

        Scanner input = new Scanner(System.in);
        System.out.println("enter a  simple mathematical operation");

        try {

            t1 = input.next();
            operator = input.next();
            t2 = input.next();
            formularesult1 = Double.parseDouble(t1);
            formularesult1 = Double.parseDouble(t2);

            input.close();
            if (operator.equals("+")) {
                result = formularesult1 + formularesult2;
            } else if (operator.equals("-")) {
                result = formularesult1 - formularesult2;
            } else if (operator.equals("/")) {
                result = formularesult1 / formularesult2;
            } else if (operator.equals("*")) {
                result = formularesult1 * formularesult2;

            } else {
                throw new InputMismatchException("Try again");
            }

            System.out.println(result);

        } catch (InputMismatchException e) {
            System.out.println("invalid format try again");

            Recurser();
        } catch (NumberFormatException e) {
            System.out.println("invalid format try again");

            Recurser();

        }

    }

}
