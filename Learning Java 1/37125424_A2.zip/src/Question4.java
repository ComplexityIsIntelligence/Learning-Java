	import java.util.Scanner;
public class Question4 {

	public static void main(String[] args) {
	
				Scanner Input=new Scanner(System.in);
				System.out.println("Please enter first x1 and y1");
				double x1=Input.nextDouble();
				double y1=Input.nextDouble();
				
				 System.out.println("Please enter x2 and y2");
				 double x2=Input.nextDouble();
				double y2=Input.nextDouble();
			
				 double firstone=(x2-x1);
				 double secondone=(y2-y1);
				 double square1 =Math.pow(firstone, 2);
				double square2 =Math.pow(secondone, 2);
				double obito=(Math.sqrt(square1+square2));
				
				System.out.println("Please enter first x3 and y3");
				double x3=Input.nextDouble();
				double y3=Input.nextDouble();
				
		
				 double naruto=(x3-x1);
				 double sasuke=(y3-y1);
				 double kakuzu =Math.pow(naruto, 2);
				double hidan=Math.pow(sasuke, 2);
				double kakashi=(Math.sqrt(kakuzu+hidan));
			
				 double sakura=(x3-x2);
				 double karin=(y3-y2);
				 double hashirama =Math.pow(sakura, 2);
				double madara=Math.pow(karin, 2);
				double minato=(Math.sqrt(hashirama+madara));
				
				
				double s=((obito+kakashi+minato)/2);
				double insider1=(s-obito);
				double insider2=(s-kakashi);
				double insider3=(s-minato);
				double bee=(s*insider1*insider2*insider3);
				double area=Math.sqrt(bee);
				System.out.printf("the area of the triange is %f%n",area);
				
			
				
				
				
				
				
				
				
				
				
				
				
				

	}

}
