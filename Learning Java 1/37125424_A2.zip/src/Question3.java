
import java.util.Scanner;
public class Question3 {

	public static void main(String[] args) {
		Scanner Input=new Scanner(System.in);
		System.out.println("Please enter first x1 and y1");
		double x1=Input.nextDouble();
		double y1=Input.nextDouble();
		
		 System.out.println("Please enter x2 and y2");
		 double x2=Input.nextDouble();
		double y2=Input.nextDouble();
		
		 double firstone=(x2-x1);
		 double secondone=(y2-y1);
		 double square1 =Math.pow(firstone, 2);
		double square2 =Math.pow(secondone, 2);
		double a=(Math.sqrt(square1+square2));
		System.out.println("the distance between the two points is"+" "+a);
		
		
	}

}