import java.util.Scanner;

public class Question1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner Input=new Scanner(System.in); 
		 System.out.println("Enter v0,v1 and t");
		 double  v0=Input.nextDouble();

		 double v1=Input.nextDouble();
	

		 double t=Input.nextDouble();
		
		 double a=((v1-v0)/t);
		 System.out.println("The average acceleration is"+" "+a);
			 
			

	}

}
