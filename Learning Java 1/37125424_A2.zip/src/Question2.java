import java.util.Scanner;

public class Question2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Scanner Input=new Scanner(System.in);
  System.out.println("PLease enter driving distance in miles");
  double d=Input.nextDouble();
  System.out.println("PLease enter miles per gallon");
  
  double g=Input.nextDouble();
  System.out.println("PLease enter price per gallon");
  
  double gs=Input.nextDouble();
  double cost=(d/g)*gs;
  
  System.out.println("The cost of driving is"+" "+cost);
	}

}
