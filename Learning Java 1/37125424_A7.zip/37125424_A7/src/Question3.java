import java.util.Scanner;

import java.util.Arrays;

public class Question3 {


    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("how many numbers in the list? ");
        int arraycounter = input.nextInt();
        System.out.print("Enter the list: ");
        double[] arrayfornumbers = new double[arraycounter];
        for (int i = 0; i < arraycounter; i++) {
            arrayfornumbers[i] = input.nextDouble();
        }
        boolean sorted = isSorted(arrayfornumbers);
        
        if (sorted == true) {
            System.out.println("it is sorted");
        } else {
            System.out.println("it is not sorted");
            input.close();
        }
    }

    public static boolean isSorted(double[] list) {

        double[] copyArray;
        copyArray = new double[list.length];

        for (int i = 0; i < list.length; i++) {
            copyArray[i] = list[i];}
            Arrays.sort(list);
            if (Arrays.equals(list, copyArray)) {
            
                return true; 
            }
                 return false;
             
            
              
              

        }
    }

