import java.util.Arrays;
import java.util.Scanner;

public class Question2 {
    public static void main(String[] args) {
        String s1 = "Enter number of students: ";
        String s2 = "Enter student grades: ";
        char grade;

        double[] numbers = getNumsFromUser(s1, s2);// gets array
        double best = getmax(numbers);// gets maximum value

        for (int i = 0; i < numbers.length; i++) {
            int studentnumber = i + 1;
            String Studentname = "student" + studentnumber;// for student name
            if (numbers[i] >= best - 10)
                grade = 'A';
            else if (numbers[i] >= best - 20)
                grade = 'B';

            else if (numbers[i] >= best - 30)
                grade = 'C';

            else if (numbers[i] >= best - 40)
                grade = 'D';
            else
                grade = 'F';
            
            System.out.println(Studentname+" score is "+numbers[i]+" grade is "+grade);


        }
    }

    public static double[] getNumsFromUser(String msg1, String msg2) {
        System.out.print(msg1);
        Scanner input = new Scanner(System.in);
        int studentcount = input.nextInt(); // no. of students
        double[] studentgradearray = new double[studentcount]; // declaration of sized array
        System.out.print(msg2);
        for (int i = 0; i < studentcount; i++) { // to loop over values to make the scanner take values

            studentgradearray[i] = input.nextDouble();
           
            
  
        }
        return studentgradearray;

    }

    public static double getmax(double[] getarray) {

        int arraylength = getarray.length;
        double[] copyArray;
        copyArray = new double[getarray.length];
        for (int i = 0; i < getarray.length; i++) {
            copyArray[i] = getarray[i];}
        Arrays.sort(copyArray);// sorts to get last value which is the maximum
        double max = copyArray[arraylength - 1];
        return max;

    }
  
}
