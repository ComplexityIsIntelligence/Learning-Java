
public class Question3 {

	public static void main(String[] args) {
		final double g=9.81;
		double t=12;
	System.out.println("distance after 12 seconds="+(g*(t*t)/2));

	}
	
}
