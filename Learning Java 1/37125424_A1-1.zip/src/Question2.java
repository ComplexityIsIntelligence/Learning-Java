
public class Question2 {

	public static void main(String[] args) {
int height=9;
int width=7;
System.out.println("perimeter="+2*(height+width));

System.out.println("area="+height*width);
	}

}
