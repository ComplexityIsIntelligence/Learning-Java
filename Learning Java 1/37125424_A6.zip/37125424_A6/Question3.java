import java.util.Scanner;

public class Question3 {
    int pete = 0;
    

    public static void main(String[] args) {
        Scanner fred = new Scanner(System.in);
        int stallion = fred.nextInt();
        if (isPalindrome(stallion)) {
            System.out.println(stallion + " is a palindrone");}
         else{
            System.out.println(stallion + " is not a palindrone");}
            fred.close();
        }
    

    

    public static int reverse(int number) {
        int pete = 0;
        String number1 = number + "";
        String reverse = "";

        for (int bob = number1.length() - 1; bob >= 0; bob--) {
            reverse += number1.charAt(bob);
            pete = Integer.valueOf(reverse);
        }

        return pete;
    }

    public static boolean isPalindrome(int number) {
        if (number == reverse(number)) {
            return true;

        }
        return false;
    }
  
}

