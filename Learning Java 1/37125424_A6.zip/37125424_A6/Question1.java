import java.util.Scanner;
public class Question1 {
    public static void main(String[] args) {
    Scanner input=new Scanner(System.in);
    System.out.println("enter the total number of seconds to get the time");
    int Totalseconds =input.nextInt();
    System.out.println("the time is"+" "+convertTime(Totalseconds));
    
input.close();
    }

public static String convertTime(int totalseconds){
    int realseconds=totalseconds%60;
    int peiceminutes=totalseconds/60;
    int realminutes=peiceminutes%60;
    int realhours=peiceminutes/60;
    String converttime=realhours+":"+realminutes+":"+realseconds;
    return converttime;




}


}