package P3;


public class Main {				
	static Game game;			
	public static void main(String[] args) {
		String ans;
		 int count=0;
		do{							
			
			game = new Game();	
			String q0="";
			String q1="";
			String q2="";
			String a0="";
			String a1="";
			String a2="";
			
            String[] q={q0,q1,q2};
			String[] a={a0,a1,a2};
			
			
			int numPlayers=game.askForInt("how many players",0,3);
		for(int i=0;i<numPlayers;i++){
        String name = game.askForText("What is your name Player"+i+"?");
			game.addPlayer(name);}
			
          
            for(int i=0;i<numPlayers;i++){
				
			game.setCurrentPlayer(i);
			String answer = game.askForText(q[i]);
			if(a[i].equals(answer)){
                count++;
				game.correct();		
			}else{
				game.incorrect();	}} 
	        
		ans = game.askForText("Play again? (Y/N)"); 
			while(ans != null && !ans.toUpperCase().equals("Y") && !ans.toUpperCase().equals("N"))
				ans = game.askForText("Invalid input. Play again? (Y/N)");
		}while(ans.toUpperCase().equals("Y"));	//play again if the user answers "Y" or "y"

		System.exit(1); 	
	}
}

