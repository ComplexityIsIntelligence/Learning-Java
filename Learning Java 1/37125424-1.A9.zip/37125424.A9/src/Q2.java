public class Q2 {
    public static void main(String[] args) {
        BankAccount bankaccount1 = new BankAccount(6.7, 33000);
        bankaccount1.withdrawal(1500);
        bankaccount1.deposit(1000);
        bankaccount1.displayInfo();
        
    }
    
}
