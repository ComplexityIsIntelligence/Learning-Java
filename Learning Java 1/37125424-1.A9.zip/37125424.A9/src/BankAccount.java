public class BankAccount {
    int id;
    double balance;
    double annualInterestRate;
    static int count;

    public BankAccount(double annualInterestRate, double balance) {
        this.annualInterestRate = annualInterestRate;
        this.balance = balance;
        count++;
        id = count;

    }

    public BankAccount() {
        this.annualInterestRate = 0;
        this.balance = 0;

    }

    public double getAnnualInterestRate() {
        return annualInterestRate;

    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;

    }

    public void setAnnualInterestRate(double annualInterestRate) {
        this.annualInterestRate = annualInterestRate;
    }

    public double getMonthlyInterest() {

        return (balance * annualInterestRate / 12) / 100;

    }

    public void withdrawal(double amount) {
        balance = balance - amount;
    }

    public void deposit(double amount) {
        balance = balance + amount;
    }

    

    public void displayInfo() {
        System.out.println("Account ID: " + id);
        System.out.println("Current Balance: " +"$"+ balance);
        System.out.printf("Annual Interest Rate : %.3f%% " , annualInterestRate);
        System.out.println();
        System.out.printf("Monthly interest rate: %.3f %%", getMonthlyInterest() / balance * 100);
        System.out.println();
        System.out.printf("Monthly Interest: $%.3f", getMonthlyInterest());
        System.out.println();

    }
}