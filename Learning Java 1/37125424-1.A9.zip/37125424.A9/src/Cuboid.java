public class Cuboid {
    double l;
     double w;
     double h;
     String color;

    public Cuboid() {
        this(1, 1, 1, "white");
    }

    public Cuboid(double l, double w, double h, String color) {
        this.color = color;
        this.l = l;
        this.w = w;
        this.h = h;

    }

    public String getColor() {
        return color;
    }

    public double getH() {
        return h;
    }

    public double getL() {
        return l;
    }

    public double getW() {
        return w;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setH(double h) {
        this.h = h;
    }

    public void setW(double w) {
        this.w = w;
    }

    public void setL(double l) {
        this.l = l;
    }

    public double getSurfaceArea() {
    
        return 2 * (l * w + l * h + w * h);
    }

    public double getVolume() {

        return l * h * w;
    }

   
    public void displayInfo() {
        System.out.println("Color: " + color);
        System.out.println("Dimensions: " + l + " X " + w + " X " + h);
        System.out.printf("Surface Area: %.2f", getSurfaceArea());
        System.out.println();
        System.out.printf("Volume: %.2f", getVolume());
        System.out.println();

    }
}
