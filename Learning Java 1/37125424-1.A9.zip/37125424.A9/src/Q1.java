public class Q1 {
    public static void main(String[] args) {
        System.out.println("Cuboid 1");
        Cuboid cuboid1 = new Cuboid();
        cuboid1.displayInfo();
        System.out.println("Cuboid 2");
        Cuboid cuboid2 = new Cuboid(8, 3.5, 5.9, "green");
        cuboid2.displayInfo();

    }

}
