import java.util.Scanner;

public class Question2_ {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("enter plate number");
        String x = input.nextLine();
        char a1 = x.charAt(0);
        char a2 = x.charAt(1);
        char a3 = x.charAt(2);
        char a4 = x.charAt(3);

        int a = (int) 'A';
        int z = (int) 'Z';
        char dash = '-';
        char ch1 = (char) (a3 - '0');
        char ch2 = (char) (a4 - '0');
        int ch3 = (int) ch1;
        int ch4 = (int) ch2;

        if ((a1 >= a) && (a1 <= z) && (a2 >= a) && (a2 <= z) && (a3 == dash) && (ch1 > 9) && (ch2 < 100) && (ch3 > 9) && (ch4 < 100)) {
            System.out.println(x + " is a valid plate number");
        } else {
            System.out.println(x + " is an invalid plate number");
        }

        input.close();
    }
}
