import java.util.Scanner;

public class Question4_ {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("enter 0 for scissor, 1 for paper, 2 for rock");
        int userinput = input.nextInt();
        int randominput = (int) (Math.random() * 3);
      
        switch (randominput) {
            case 0:
                System.out.print("Computer is scissors.  ");
                break;
            case 1:
                System.out.print("Computer is rock.  ");
                break;
            case 2:
                System.out.print("Computer is paper.  ");
                break;

        }

        switch (userinput) {
            case 0:
                System.out.print("You are scissors.  ");
                break;
            case 1:
                System.out.print("You are rock.  ");
                break;
            case 2:
                System.out.print("You are paper.  ");
                break;
        }
        if (userinput==randominput){
            System.out.println("draw");}
            else
               if ((userinput==2)&&(randominput==1)){
                   System.out.println("You win");}
                   else
                   if ((userinput==0)&&(randominput==2)){
                       System.out.println("You win"); }
                 else
               if ((userinput==1)&&(randominput==0)){
                   System.out.println("You win");}
                   else {
                       System.out.println("you lost");
                   }
            
                   input.close();

        
    }
}