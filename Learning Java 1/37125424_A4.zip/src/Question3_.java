import java.util.Scanner;

public class Question3_ {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("enter the length of 3 sides");
        double x1 = input.nextDouble();
        double x2 = input.nextDouble();
        double x3 = input.nextDouble();
        double xsupreme = x1 + x2 + x3;

        if ((xsupreme > 0) && (x1 + x2 > x3) && (x2 + x3 > x1) && (x1 + x3 > x2)) {
            System.out.println("the perimeter is " + xsupreme);
        } else {
            System.out.println("Input is invalid");
            input.close();
        }
    }
}
