import java.util.Scanner;

public class Question1_ {
	public static void main(String[] args) {
		Scanner fred = new Scanner(System.in);

		System.out.println("Enter a letter");

		char rawCharacter = fred.next().charAt(0);
		char character = Character.toLowerCase(rawCharacter);

		if (character >= 'a' && character <= 'z') {
			if ((character == 'a') || (character == 'e') || (character == 'i') || (character == 'o') || (character == 'u')) {
				System.out.println("vowel");
			} else {
				System.out.println("consanant");
			}
		} else {
			System.out.println("invalid input");
		}

		fred.close();
	}
}