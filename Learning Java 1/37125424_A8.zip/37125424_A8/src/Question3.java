import java.util.Scanner;

public class Question3 {
    public static void main(String[] args) {
        int i = 0;
        int count = 0;
        String[][] provinces = {
                { "Alberta", "British Columbia", "Manitoba", "New Bumswick", "Newfoundland and Labrador", "Nova Scotia",
                        "Ontario ", "Prince Edward Island ", "Quebec ", "Saskatchewan " },
                { "Edmonton", "Victoria", "Winnipeg", "Fredericton", "St. John's", "Halifax", "Toronto",
                        "Charlottetown", "Quebec City", "Regina" }
        };
        Scanner input = new Scanner(System.in);
        while (i < 10) {
            System.out.print("what is the capital of " + provinces[0][i] + " :");
            String answer = input.nextLine();
            if (answer.equals(provinces[1][i])) {
                count++;

            }
            i++;
        }

        System.out.println("you got " + count + " question(s) right.");
    }
}
