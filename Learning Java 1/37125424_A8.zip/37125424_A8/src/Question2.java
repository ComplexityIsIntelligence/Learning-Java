
import java.util.Arrays;
import java.util.Scanner;

public class Question2 {
    public static void main(String[] args) {
        int x = 0;
        int[][] m1 = { { 14, 11, 13, 12 },
                { 18, 15, 13, 13 },
                { 19, 16, 15, 17 } };
        int[][] m2 = { { 54, 53, 51, 52 },
                { 51, 59, 52, 56 },
                { 53, 54, 52, 58 } };
        System.out.println("First array:");
        displayArray(m1);
        System.out.println("Second array:");
        displayArray(m2);
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter your desired colum number");
        int colno = input.nextInt();
        System.out.println("Please write 1 for array one and 2 for array two");
        int choice = input.nextInt();
        if (choice == 1) {
            x = sumCol(m1, colno);
            System.out.println("the sum of the first array at column number " + colno + " is " + x);
        }
        if (choice == 2) {
            x = sumCol(m2, colno);
            System.out.println("the sum of the second array at column number " + colno + "is " + x);

        } else {
            while (choice != 1 & choice != 2) {
                System.out.println("invalid choice");
                System.out.println("Please write 1 for array one and 2 for array two");
                choice = input.nextInt();
                if (choice == 1)
                    x = sumCol(m1, colno);

                if (choice == 2)
                    x = sumCol(m2, colno);
            }

        }

      
    }

    public static int sumCol(int[][] m, int colIdx) {
        colIdx=colIdx-1;
        int total = 0;
        int i = 0;
        while (i < m.length) {
            int sum = m[i][colIdx];

            total += sum;
            i++;
        }

        return total;
    }

    public static void displayArray(int[][] m) {
        for (int r = 0; r < m.length; r++) {
            for (int c = 0; c < m[r].length; c++)
                System.out.print(m[r][c] + " ");
            System.out.println();
        }
    }

}
