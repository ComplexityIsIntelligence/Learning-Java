
import java.util.Scanner;

public class Question1 {
    public static void main(String[] args) {
        double x;
        int count = 0;
        int countnegative = 0;
        int counteven = 0;
        int countodd = 0;
        double sum = 0;
        Scanner input = new Scanner(System.in);
        do {
            if (count == 0) {
                System.out.print("please enter the first integer ");
            } else {
                System.out.print("enter the next integer ");
            }
            x = input.nextDouble();

            if (x > 0)
                ;
            count++;

            if (x < 0)
                countnegative++;
            if (x % 2 == 0)
                counteven++;
            if (x % 2 != 0)
                countodd++;
            sum += x;

        }

        while (x != 0);
        if (count == 1) {
            System.out.println("no numbers entered except 0");
        } else {

            System.out.println("count is all positives is " + count);
            System.out.println("the count of all negatives is " + countnegative);
            System.out.println("the count of all evens is " + counteven);
            System.out.println("the count of all odds is " + countodd);
            System.out.println("the sum is " + sum);
            double average = sum / count;
            System.out.println("the average of all the numbers " + average);
        }
        input.close();
    }

}
