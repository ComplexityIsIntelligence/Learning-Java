import java.util.Scanner;

public class question4 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("enter no. of students");
        int count = input.nextInt();

        String bestStudentName = "",    secondBestStudentName = "";
        double bestScore = 0,           secondBestScore = 0;

        for (int index = 0; index < count; index++) {
            

            input.nextLine();

            System.out.println("Enter a student name");
            String name = input.nextLine();
            System.out.println("enter student score");
            double score = input.nextDouble();

            if (score > bestScore) {
                bestStudentName = name;
                bestScore = score;
            } else if (score > secondBestScore) {
                secondBestStudentName = name;
                secondBestScore = score;
            }
         
            
        }


        System.out.println("Top two students:");
        System.out.println(bestStudentName + "'s score is " + bestScore);
        System.out.println(secondBestStudentName + "'s score is " + secondBestScore);
        
input.close();
    }

}
