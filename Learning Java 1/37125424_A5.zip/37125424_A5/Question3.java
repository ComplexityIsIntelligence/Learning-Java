public class question3 {
    public static void main(String[] args) {
        int count = 0;
        for (int x = 100, sum = 0; x >= 100 && x <= 200; sum = 0, x++) {
            if ((x % 5 == 0) ^ (x % 6 == 0)) {
                sum += x;
                System.out.print(sum+" ");
               count++;
            }
            if (count==10) {
            System.out.println();
            count=0;
            }
        }

    }
}
