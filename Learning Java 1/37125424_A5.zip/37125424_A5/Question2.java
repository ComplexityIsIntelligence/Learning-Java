public class Question2 {// 10,000
    public static void main(String[] args) {
        for (int insidething = 10000, sum = 0; insidething > 0; sum = 0, insidething--) {
            for (int outsidething = insidething - 1; outsidething > 0; outsidething--) {
                if (insidething % outsidething == 0) {
                    sum += outsidething;
                }
            }
            
            if (sum == insidething) {
                System.out.println(insidething + " is a perfect number");
            }
        }
    }
}
