import java.util.Scanner;

public class Question3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Scanner Input= new Scanner(System.in);
 System.out.println("Enter an integer between 0 and 999(inclusive)");
 int z = Input.nextInt();
if (0<z&&z<=999){
	int marvel=z%10; //rem is last digt
	int DC=z/10;  //first 2 digts
	int comics=DC/10; 
	int lego=DC%10;
	int realone= marvel+lego+comics;
	System.out.printf("The sum of all the digts is %d",realone);
}else 
	System.out.println("write a number which is between 0 and 999(inclusive");

}

	}


