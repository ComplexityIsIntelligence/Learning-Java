import java.util.Scanner;

public class Question4 {

	public static void main(String[] args) {
		
	
Scanner Input=new Scanner(System.in);  //getting user to enter number
System.out.println("Enter any number");
Double number1=Input.nextDouble();

Scanner input=new Scanner(System.in);  //getting user to enter another number
System.out.println("Enter another number");
Double number2=input.nextDouble();
Double number_X=number1+number2;  //basic addition
System.out.println("This is basic arithmetic");
System.out.println("Here is the sum of the two numbers"+"   "+number_X);
Double number_omegaX=number1/number2;  //basic division
System.out.println("Here is what happens when you divide number1 by number2"+" "+number_omegaX);
 System.out.println();
System.out.println("this is augmented assigment operators");
Double numberalphagenius=number1+=10; //addition assigment
Double numbersobig=number2/=30; //divison assigment
System.out.println("addidtion augment makes the number=number+10"+"    "+numberalphagenius);
System.out.println("division augment makes the number=number/30"+"    "+numbersobig);
System.out.println();
System.out.println("these are increment and decrement operators");
double newnumbersrock=--number1;//pre-decrement
double theaboveiswrong=number2++;//post-increment
System.out.println("(for number one)a pre decrement will on the same line show a new number 1 less"+"    "+newnumbersrock);
System.out.println("(for number two)a post increment will on the next line show a new number 1 more"+"   "+theaboveiswrong);




	}

}
