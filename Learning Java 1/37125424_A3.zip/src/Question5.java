import java.util.Random;
public class Question5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Random rand= new Random();
	     char c0 =(char)('A'+rand.nextInt(26));
	     char c1 =(char)('A'+rand.nextInt(26));
	     char c2 =(char)('A'+rand.nextInt(26));
	     int y0 =rand.nextInt(10);
	     int y1 =rand.nextInt(10);
	     int y2 =rand.nextInt(10);
	     int y3 =rand.nextInt(10);
	  
			
			System.out.printf("A random vehicle plate is %s%s%s%d%d%d%d",c0,c1,c2,y0,y1,y2,y3);
	}

}
