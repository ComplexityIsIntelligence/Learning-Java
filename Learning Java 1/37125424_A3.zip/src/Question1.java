import java.util.Scanner;

public class Question1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the temperature in Fahrenheit between  -58 F and 41");
 Scanner input=new Scanner(System.in);
 Double ta =input.nextDouble();
 
 System.out.println("Enter the wind speed miles per hour(must be greater than or equal to 2)");
 Double v=input.nextDouble();
 
 Double Twc= 35.74+0.6215*ta-35.75*(Math.pow(v, 0.16))+(0.4275*ta*(Math.pow(v, 0.16)));
 System.out.printf("the windchill is %f", Twc);
 
 
	}

}
