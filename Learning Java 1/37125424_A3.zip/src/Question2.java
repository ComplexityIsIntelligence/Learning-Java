import java.util.Scanner;

public class Question2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter a real number");
		Scanner Input=new Scanner(System.in);
		double r=Input.nextDouble();
		int ro=(int) (r);
		System.out.println("The number befrore the decimal point is"+" "+ro);
		double fraction =r-ro;
		System.out.println("the numbers after the decimal point are"+" "+fraction);
		

	}

}
